﻿using SnakeClientTCP;
using System.Collections;
using System.Diagnostics;

namespace Snake
{
    sealed class Snake
    {
        static Snake()
        {
            SnakeQueue.Enqueue(new SnakePosition(8, 10));
            SnakeQueue.Enqueue(new SnakePosition(7, 10));
            SnakeQueue.Enqueue(new SnakePosition(6, 10));
            SnakeQueue.Enqueue(new SnakePosition(5, 10));
            MainSnake.KeyInfo = ConsoleKey.RightArrow;
        }
        public static ushort Score = 0;
        public static int SnakeSpeed { get; set; } = 110;
        private static ushort Count { get; set; } = default;

        public static Stack<SnakePosition>? ClearPositions = new Stack<SnakePosition>();
        public static Queue<SnakePosition>? SnakeQueue { get; set; } = new Queue<SnakePosition>();

        public async static Task DirectionHandler(ConsoleKey key)
        {
            switch (key)
            {
                case ConsoleKey.UpArrow:
                    await DrawUp();
                    break;
                case ConsoleKey.DownArrow:
                    await DrawDown();
                    break;
                case ConsoleKey.LeftArrow:
                    await DrawLeft();
                    break;
                case ConsoleKey.RightArrow:
                    await DrawRight();
                    break;
            }
        }
        
        private static Task DrawUp()
        {
            if (Monitor.TryEnter(Networking.drawlocker))
            {
                Count = Convert.ToUInt16(SnakeQueue.Count);

                SnakePosition snakePositionHead = SnakeQueue.Dequeue(); ClearPositions.Push(snakePositionHead);

                {
                    SnakePosition snakePosition = new SnakePosition(snakePositionHead.Left, Convert.ToSByte(snakePositionHead.Top - 1));
                    ClearPositions.Push(snakePosition);

                    SetCursorPosition(snakePosition.Left, snakePosition.Top); Write("█");

                    SnakeQueue.Enqueue(snakePosition);
                }
                FoodEated(snakePositionHead);
                for (ushort i = 1; i < Count; i++)
                {

                    SetCursorPosition(snakePositionHead.Left, snakePositionHead.Top); Write("█");
                    SnakeQueue.Enqueue(snakePositionHead);
                    ClearPositions.Push(snakePositionHead);


                    SnakePosition positionDo = SnakeQueue.Dequeue();
                    ClearPositions.Push(positionDo);
                    snakePositionHead = positionDo;
                }
                Networking.SendData<Queue<SnakePosition>?>(SnakeQueue).Wait();
                Task.Delay(SnakeSpeed).Wait();
                Clear();
                Monitor.Exit(Networking.drawlocker);
            }
            return Task.CompletedTask;
        }
        private static Task DrawDown()
        {
            if (Monitor.TryEnter(Networking.drawlocker))
            {
                Count = Convert.ToUInt16(SnakeQueue.Count);

                SnakePosition snakePositionHead = SnakeQueue.Dequeue(); ClearPositions.Push(snakePositionHead);

                {
                    SnakePosition snakePosition = new SnakePosition(snakePositionHead.Left, Convert.ToSByte(snakePositionHead.Top + 1));
                    ClearPositions.Push(snakePosition);

                    SetCursorPosition(snakePosition.Left, snakePosition.Top); Write("█");

                    SnakeQueue.Enqueue(snakePosition);
                }
                FoodEated(snakePositionHead);
                for (ushort i = 1; i < Count; i++)
                {

                    SetCursorPosition(snakePositionHead.Left, snakePositionHead.Top); Write("█");
                    SnakeQueue.Enqueue(snakePositionHead);
                    ClearPositions.Push(snakePositionHead);


                    SnakePosition positionDo = SnakeQueue.Dequeue();
                    ClearPositions.Push(positionDo);
                    snakePositionHead = positionDo;
                }
                Networking.SendData<Queue<SnakePosition>?>(SnakeQueue).Wait();
                Task.Delay(SnakeSpeed).Wait();
                Clear();
                Monitor.Exit(Networking.drawlocker);
            }
            return Task.CompletedTask;
        } 
        private static Task DrawRight()
        {
            if (Monitor.TryEnter(Networking.drawlocker))
            {
                Count = Convert.ToUInt16(SnakeQueue.Count);

                SnakePosition snakePositionHead = SnakeQueue.Dequeue(); ClearPositions.Push(snakePositionHead);

                {
                    SnakePosition snakePosition = new SnakePosition(Convert.ToSByte(snakePositionHead.Left + 1), snakePositionHead.Top);
                    ClearPositions.Push(snakePosition);

                    SetCursorPosition(snakePosition.Left, snakePosition.Top); Write("█");

                    SnakeQueue.Enqueue(snakePosition);
                }
                FoodEated(snakePositionHead);
                for (ushort i = 1; i < Count; i++)
                {

                    SetCursorPosition(snakePositionHead.Left, snakePositionHead.Top); Write("█");
                    SnakeQueue.Enqueue(snakePositionHead);
                    ClearPositions.Push(snakePositionHead);


                    SnakePosition positionDo = SnakeQueue.Dequeue();
                    ClearPositions.Push(positionDo);
                    snakePositionHead = positionDo;
                }
                Networking.SendData<Queue<SnakePosition>?>(SnakeQueue).Wait();
                Task.Delay(SnakeSpeed).Wait();
                Clear();
                Monitor.Exit(Networking.drawlocker);
            }
            return Task.CompletedTask;
        }
        private static Task DrawLeft()
        {
            if (Monitor.TryEnter(Networking.drawlocker)) 
            {
                Count = Convert.ToUInt16(SnakeQueue.Count);

                SnakePosition snakePositionHead = SnakeQueue.Dequeue(); ClearPositions.Push(snakePositionHead);

                {
                    SnakePosition snakePosition = new SnakePosition(Convert.ToSByte(snakePositionHead.Left - 1), snakePositionHead.Top);
                    ClearPositions.Push(snakePosition);

                    SetCursorPosition(snakePosition.Left, snakePosition.Top); Write("█");

                    SnakeQueue.Enqueue(snakePosition);
                }
                FoodEated(snakePositionHead);
                for (ushort i = 1; i < Count; i++)
                {

                    SetCursorPosition(snakePositionHead.Left, snakePositionHead.Top); Write("█");
                    SnakeQueue.Enqueue(snakePositionHead);
                    ClearPositions.Push(snakePositionHead);


                    SnakePosition positionDo = SnakeQueue.Dequeue();
                    ClearPositions.Push(positionDo);
                    snakePositionHead = positionDo;
                }
                Networking.SendData<Queue<SnakePosition>?>(SnakeQueue).Wait();
                Task.Delay(SnakeSpeed).Wait();
                Clear();
                Monitor.Exit(Networking.drawlocker);
            }
            return Task.CompletedTask;
        }
       
        private static void Clear()
        {
            ushort count = Convert.ToUInt16(ClearPositions.Count);
            for(ushort i = 0; i < count;i++) 
            {
                SnakePosition stackPosition = ClearPositions.Pop(); 
                SetCursorPosition(stackPosition.Left , stackPosition.Top);
                Write(' ');
            }
            ClearPositions.Clear();
        }
        public static void FoodEated(SnakePosition snakePosition) 
        {
            if (snakePosition.Equals(MainSnake.FoodPosition))
            {
                    Task.Run(() => Beep(1500, 90));
                    MapGenerator.RequesFood();
                    Score++;
                    SnakeQueue.Enqueue(new SnakePosition(118, 29));
                    SetCursorPosition(108, 27); Write(Score);
            }
            else if (snakePosition.Top == 0 || snakePosition.Top == 26)
            {
                    throw new GameOverExeption();
            }
            else if (snakePosition.Left == 0 || snakePosition.Left == 119)
            {
                    throw new GameOverExeption();
            }
        }
    }
    public struct SnakePosition
    {
        public SnakePosition(sbyte Left, sbyte Top)
        {
            this.Top = Top;
            this.Left = Left;
        }

        public sbyte Top { get; set; }
        public sbyte Left { get; set; }
    }
    

    class GameOverExeption : Exception { }
}
