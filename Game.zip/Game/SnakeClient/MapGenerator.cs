﻿using Snake;
using System.Text;

namespace SnakeClientTCP
{
    static class MapGenerator
    {
        public static Random Random = new Random();
        public static void ChangeEncoding(Encoding encoding) => Console.OutputEncoding = encoding;
        public static void DrawBoards()
        {
            ForegroundColor = ConsoleColor.Blue;
            for (sbyte i = 0; i < MainSnake.Width; i++)
            {
                Write("▅");
            }

            for (sbyte i = 1; i < MainSnake.Height - 4; i++)
            {
                Task.Delay(5).Wait();
                SetCursorPosition(0, i);
                Write("█");
            }

            for (sbyte i = 1; i < MainSnake.Height - 4; i++)
            {
                SetCursorPosition(MainSnake.Width - 2, i);
                Task.Delay(5).Wait();
                Write("█");
            }

            for (sbyte i = 0; i < MainSnake.Width - 1; i++)
            {
                SetCursorPosition(i, MainSnake.Height - 4);
                Write("▀");
            }

            SetCursorPosition(1, 1);
            Write(" ");

            SetCursorPosition(0, 1);
            Write("█");
            ResetColor();

            SetCursorPosition(0 , 27);Write($"Адрес сервера: {MainSnake.IPEndPoint}");
            SetCursorPosition(0, 28);Write("------------------------------------------------------------------------------------------------------------------------");
            SetCursorPosition(90 , 27);Write("Количество очков: 0");
        }
        public static async Task RequesFood() => await Networking.socket.SendAsync(Encoding.UTF8.GetBytes("@"));
    }
}
