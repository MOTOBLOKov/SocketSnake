﻿using Snake;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace SnakeClientTCP
{
    static public class Networking
    {
        public static object networklocker = new object();
        public static object drawlocker = new object();

        public static Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

        public static async Task Connect() => await socket.ConnectAsync(MainSnake.Address , MainSnake.Port);

        public static async Task<String> ReciveData() 
        {
            StringBuilder sb = new StringBuilder();
            int bytes = 0;
            byte[] buffer = new byte[512];
            do
            {
                bytes = await socket.ReceiveAsync(buffer);

                string reciveddata = Encoding.UTF8.GetString(buffer, 0, bytes);

                sb.Append(reciveddata);

                if (reciveddata[0] == '@') 
                    ResponseFood(reciveddata); 

                if (reciveddata[reciveddata.Length - 1] == '^')
                    break; 

            } while (bytes > 0);

            string[] str = sb.ToString().Trim().Split('^');

            return str[0];
        }

        public static void ResponseFood(string reciveddata) 
        {
            lock (Networking.drawlocker) 
            {
                SnakePosition pos = JsonConvert.DeserializeObject<SnakePosition>(reciveddata[1..reciveddata.Length]);

                SetCursorPosition(pos.Left, pos.Top);

                ForegroundColor = ConsoleColor.Red;

                Write('●');

                MainSnake.FoodPosition = pos;

                ResetColor();
            }
        }

        public static async Task SendData<T>(T data)
        {
             string quant = JsonConvert.SerializeObject(data) + '^';

             socket.SendAsync(Encoding.UTF8.GetBytes(quant));
             await Task.Delay(30);
        }
    }
    public class StartInfo 
    {
        public static sbyte Top { get; set; }

        public static SnakePosition FoodPosition { get; set; }

    }
}
