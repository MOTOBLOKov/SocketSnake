﻿global using static System.Console;
global using System.Net.Sockets;
using System.Text;
using SnakeClientTCP;
using System.Net;
using Newtonsoft.Json;

namespace Snake
{
    static class MainSnake
    {
        public const sbyte Width = 121;
        public const sbyte Height = 30;
        public static ConsoleKey KeyInfo;
        public static IPAddress Address;
        public static int Port = default;
        public static IPEndPoint IPEndPoint;
        public static SnakePosition FoodPosition { get; set; } = default;
        private static Queue<SnakePosition>[]? oldpositions { get; set; }

        public static async Task Main()
        {
            try
            {
                MapGenerator.ChangeEncoding(Encoding.UTF8);
                SetWindowPosition(0, 0);
                SetWindowSize(Width, Height);
                CursorVisible = false;

                using (FileStream fs = new FileStream("IpAddres.ini", FileMode.OpenOrCreate, FileAccess.Read, FileShare.ReadWrite))
                {
                    using (StreamReader sr = new StreamReader(fs))
                    {
                        Address = IPAddress.Parse(sr.ReadToEnd().Trim());
                    }
                }

                using (FileStream fs = new FileStream("Port.ini", FileMode.OpenOrCreate, FileAccess.Read, FileShare.ReadWrite))
                {
                    using (StreamReader sr = new StreamReader(fs))
                    {
                        Port = Int32.Parse(sr.ReadToEnd().Trim());
                    }
                }

                IPEndPoint = new IPEndPoint(Address, Port);

                MapGenerator.DrawBoards();

                Task.Run(() =>
                {
                    while (true)
                    {
                        KeyInfo = ReadKey().Key;
                    }
                });

                await Networking.Connect();
                new Thread(Reciving).Start();
                byte[] buffer = new byte[8];
                int recivedbytes = await Networking.socket.ReceiveAsync(buffer);

                if (Encoding.UTF8.GetString(buffer , 0 , recivedbytes) == "OK") 
                {
                    MapGenerator.RequesFood();
                    while (true)
                    {
                       await Snake.DirectionHandler(KeyInfo);
                    }
                }
            }
            catch (GameOverExeption)
            {

                Write("""
                 Вы проиграли
                    ┊╱▔▔▔╲┊┊╯┊╓┳━━━━┓
                    ▕▕▔▔▔▔▏╭╯┊║┃┏┈┈┓┃
                    ╭╱╭▅╭▅▏╭┊┊║┃┊┏╮┊┃
                    ╰╮┈╭╮▕┊╭╯┊║┃┗┫┣┛┃
                    ┊┃╰━━╱┏━┳╮╙┻━┫┣━┛
                    ▔╲╰━╯▔┃╳┣╯┊─╭┫┣╮
                    ▔▔▔▔▔▔╰━╯─▔▔╰━━╯
                 """);
            }
            catch (ArgumentOutOfRangeException)
            {

                Write("""
                 Вы проиграли 
                    ┊╱▔▔▔╲┊┊╯┊╓┳━━━━┓
                    ▕▕▔▔▔▔▏╭╯┊║┃┏┈┈┓┃
                    ╭╱╭▅╭▅▏╭┊┊║┃┊┏╮┊┃
                    ╰╮┈╭╮▕┊╭╯┊║┃┗┫┣┛┃
                    ┊┃╰━━╱┏━┳╮╙┻━┫┣━┛
                    ▔╲╰━╯▔┃╳┣╯┊─╭┫┣╮
                    ▔▔▔▔▔▔╰━╯─▔▔╰━━╯ 
                 """);
            }
        }
        private static void Reciving() => RecivingHandler().Wait();
        private static async Task RecivingHandler()
        {
            try
            {
                while (true)
                {
                    AAA:
                    string somestr = await Networking.ReciveData();

                    if (oldpositions != null)
                    {
                        for (int it = 0; it < oldpositions.Length; it++)
                        {
                            int count = oldpositions[it].Count;

                            for (int i = 0; i < count; i++)
                            {
                                SnakePosition cell = oldpositions[it].Dequeue();
                                SetCursorPosition(cell.Left, cell.Top);
                                Write(' ');
                            }
                        }
                    }

                    try
                    {
                        Queue<SnakePosition>[] pos = JsonConvert.DeserializeObject<Queue<SnakePosition>[]>(somestr);
                        oldpositions = JsonConvert.DeserializeObject<Queue<SnakePosition>[]>(somestr);

                        for (int it = 0; it < pos.Length; it++)
                        {
                            int count = pos[it].Count;

                            for (int i = 0; i < count; i++)
                            {
                                SnakePosition cell = pos[it].Dequeue();
                                SetCursorPosition(cell.Left, cell.Top);
                                Write('█');
                            }
                        }
                    }
                    catch 
                    {
                        goto AAA;
                    }
                }
            }
            catch (Exception ex) { await Out.WriteLineAsync(ex.Message.ToString()); await Out.WriteLineAsync(ex.StackTrace); }
        }
    }
}
