﻿using System.Net;
using System.Net.Sockets;
using System.Text;

namespace ConsoleApp2
{
    sealed class Program
    {
        private static object locker = new object();

        public static List<Socket> ConnectedUsers = new List<Socket>();

        static async Task Main(string[] args)
        {
           Console.CursorVisible = false;

           Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp); 
            
                socket.Bind(await Dir.GetBindingIP()); socket.Listen(await Dir.GetCount());

                await Console.Out.WriteLineAsync($"[Успешная инициализация]:[Адрес Сервера]-[{socket.LocalEndPoint}]\n\t[{DateTime.Now}] Ожидание подключений...");

                Task.Run(() => { while (true) {
                        Task.Delay(10000).Wait(); Console.WriteLine($"\t\t[Количиство активных пользователей] {ConnectedUsers.Count}");
                }});

            using CancellationTokenSource cancellationToken = new CancellationTokenSource();
            CancellationToken cts = cancellationToken.Token;

            Task waitingusers = new Task(async() => {

                try
                {

                    while (true)
                    {
                        Socket socket1 = await socket.AcceptAsync();
                        await UserConnected(socket1);

                        await Console.Out.WriteLineAsync($"\t[подключившийся пользователь {{{socket1.RemoteEndPoint}}}]");

                        if (cts.IsCancellationRequested) 
                        {
                            RemoveFromList(socket);
                            cts.ThrowIfCancellationRequested();
                        }   
                    }
                }
                catch (OperationCanceledException) { Console.WriteLine("\t[Раунд уже начался]"); }
              
            } , cts);

            waitingusers.Start();

            while (!cts.IsCancellationRequested) 
            {
                if (Console.ReadKey().Key == ConsoleKey.Enter) 
                {
                    await Task.Run(async() => {

                        Console.WriteLine("\t {Начало раунда через: 3}");
                        await Task.Delay(1000);

                        Console.WriteLine("\t {Начало раунда через: 2}");
                        await Task.Delay(1000);

                        Console.WriteLine("\t {Начало раунда через: 1}");
                        await Task.Delay(1000);

                        cancellationToken.Cancel();

                    });       
                }
            }
            new Thread(SnakeServerTCP.Round.StartRound).Start();
        }
        private static async Task UserConnected(Socket sock) 
        {
            try
            {
                AddToList(sock);
            }
            catch (SocketException)
            {
                await Console.Out.WriteLineAsync($"\t[Пользователь принудительно окончил сеанс] {sock.RemoteEndPoint}");
                RemoveFromList(sock);
                sock.Dispose();
            }   
        }


        public static void RemoveFromList(Socket endPoint) 
        {
            lock (locker){ ConnectedUsers.Remove(endPoint); }
        }
        private static void AddToList(Socket endPoint) 
        {
            lock (locker) { ConnectedUsers.Add(endPoint); }
        }
    }

  
}
