﻿namespace ConsoleApp2
{
    public class StartInfo
    {
        public static sbyte Top { get; set; }

        public static SnakePosition FoodPosition { get; set; }

    }
    public struct SnakePosition
    {
        public SnakePosition(sbyte Left, sbyte Top)
        {
            this.Top = Top;
            this.Left = Left;
        }

        public sbyte Top { get; set; }
        public sbyte Left { get; set; }
    }
}
