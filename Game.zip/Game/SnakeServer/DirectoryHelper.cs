﻿using System.Net;

namespace ConsoleApp2
{
    public static class Dir
    {
        public static async Task<IPEndPoint> GetBindingIP()
        {
            try
            {
                string ipaddress;
                int port;

                using (FileStream fs = new FileStream("ServerIP.ini", FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.ReadWrite))
                {
                    string content = await new StreamReader(fs).ReadToEndAsync();
                    ipaddress = content.Trim();
                }
                using (FileStream fs = new FileStream("ServerPort.ini", FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.ReadWrite))
                {
                    string ntrim = await new StreamReader(fs).ReadToEndAsync();
                    int content = int.Parse(ntrim.Trim());
                    port = content;
                }

                return new IPEndPoint(IPAddress.Parse(ipaddress), port);
            }
            catch (Exception ex)
            {
                await Console.Out.WriteLineAsync(ex.Message);
                return new IPEndPoint(IPAddress.Parse("127.0.0.1"), 8080);
            }
        }
        public static async Task<int> GetCount()
        {
            using (FileStream fs = new FileStream("MaxUsersCount.ini", FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.ReadWrite))
            {
                string ntrim = await new StreamReader(fs).ReadToEndAsync();
                return int.Parse(ntrim.Trim());
            }
        }
    }
}