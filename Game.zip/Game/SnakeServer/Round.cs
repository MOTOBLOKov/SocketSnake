﻿using ConsoleApp2;
using System.Text;
using Newtonsoft.Json;
using System.Net.Sockets;

namespace SnakeServerTCP
{
    sealed class Round
    {
        private static Queue<SnakePosition>[] snakePositions = new Queue<SnakePosition>[Program.ConnectedUsers.Count];

        private static object sendLocker = new object();
        private static readonly Random random = new Random();

        public static Semaphore semaphore = new Semaphore(3,3);
        public async static void StartRound() => RoundHandler().Wait();

        private async static Task RoundHandler() 
        {
            for (sbyte i = 0; i < Program.ConnectedUsers.Count; i++) 
            {
                PlayerHandler(i);
                Program.ConnectedUsers[i].SendAsync(Encoding.UTF8.GetBytes("OK"));
            }
            
            await Task.Delay(-1);
        }
        private static async Task PlayerHandler(sbyte playerindex) 
        {
            try 
            {
                while (true)
                {
                    StringBuilder sb = new StringBuilder();
                    int bytes = 0;
                    byte[] buffer = new byte[1024];
                    do
                    {    
                        bytes = await Program.ConnectedUsers[playerindex].ReceiveAsync(buffer);

                        string reciveddata = Encoding.UTF8.GetString(buffer, 0, bytes);

                        sb.Append(reciveddata);

                        if (reciveddata[0] == '@')
                            SendFoodPosition();

                        if (reciveddata[reciveddata.Length -1] == '^') 
                        { break; }

                    } while (bytes > 0);


                    string[] str = sb.ToString().Trim().Split('^');

                    Queue<SnakePosition>[]? positions = new Queue<SnakePosition>[str.Length];

                    using (FileStream file = new FileStream("C:\\Users\\aslan\\OneDrive\\Рабочий стол\\Text Document(1).txt", FileMode.Append, FileAccess.Write , FileShare.ReadWrite))
                    {
                        using (StreamWriter sw = new StreamWriter(file))
                        {
                            foreach (string s in str)
                                await sw.WriteLineAsync(s + '\n');
                        }
                    }

                    try
                    {
                        for (sbyte i = 0; i < str.Length; i++)
                        {
                            positions[i] = JsonConvert.DeserializeObject<Queue<SnakePosition>?>(str[i]);
                        }

                        for (uint i = 0; i < positions.Length - 1; i++)
                        {
                            Queue<SnakePosition> snakePosition = positions[i];
                            snakePositions[playerindex] = snakePosition;
                        }
                    }
                    catch { Console.Beep(2000 , 500); }

                    semaphore.WaitOne();

                    try
                    {
                        lock (sendLocker) {

                            Queue<SnakePosition>[] joi = snakePositions;
                            string jstr = JsonConvert.SerializeObject(joi) + '^';
                            Console.WriteLine(jstr);
                            Program.ConnectedUsers[playerindex].SendAsync(Encoding.UTF8.GetBytes(jstr));

                        } 
                    }
                    finally 
                    {
                       semaphore.Release();
                    }
                } 
            }
            catch (Exception ex)
            {
                await Console.Out.WriteLineAsync(ex.Message);
                await Console.Out.WriteLineAsync(ex.StackTrace);
                Program.RemoveFromList(Program.ConnectedUsers[playerindex]);
            }
        }
        private static Object foodlocker = new();
        public static void SendFoodPosition() 
        {
            if (Monitor.TryEnter(foodlocker))
            {
                SnakePosition snake = new SnakePosition((sbyte)random.Next(1, 119), (sbyte)random.Next(1, 26));

                string ser = "@";
                ser += JsonConvert.SerializeObject(snake);
                Console.WriteLine(ser);
                foreach (Socket socket in Program.ConnectedUsers)
                    socket.Send(Encoding.UTF8.GetBytes(ser));
                Task.Delay(100);
                Monitor.Exit(foodlocker);
            }
        }
    }
}



